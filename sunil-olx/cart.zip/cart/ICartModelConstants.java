package cart;

public interface ICartModelConstants {
	String CART="CART",
	ID="ID",
	CLASSIFIED_ID="CLASSIFIED_ID",
	BIDPRICE="BIDPRICE",
	STATUS="STATUS",
	BIDDER_ID="BIDDER_ID";
}
