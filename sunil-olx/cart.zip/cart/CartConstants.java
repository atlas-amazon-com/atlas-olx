package cart;

public class CartConstants {

}
